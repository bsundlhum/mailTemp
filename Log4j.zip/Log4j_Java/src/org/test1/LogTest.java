package org.test1;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class LogTest {
	static Logger log = LogManager.getLogger(LogTest.class);
	public static void tests(){
		for(int i=0;i<10000;i++){
		    log.trace("测试级别trace");
		    log.warn("测试级别：warn");
		    log.debug("方法测试");
		    log.error("方法发生错误，test");
		}
		
	}
	
	//测试try..catch的exception结果会不会自动打印在日志中
	public static void test2(){
		try{
			int i = 3/0;
		}catch(Exception e){
			e.printStackTrace();
			log.debug(e);
		}
	}
	
	public static void main(String[] args) throws Exception{
		//tests();
		//log.debug("日志测试");
		test2();
	}
}
